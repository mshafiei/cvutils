# cvutils
Computer Vision utilities that I frequently use
